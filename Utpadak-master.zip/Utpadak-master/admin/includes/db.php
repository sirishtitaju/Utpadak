<?php 

$con = mysqli_connect("localhost","root","","utpadak_db");

?>